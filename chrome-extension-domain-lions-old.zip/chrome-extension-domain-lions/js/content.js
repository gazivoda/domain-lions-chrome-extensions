'use strict';
let textExists = false;
let modalExists = false;
let email;
let phoneNumber;
let domain;
let leadList;
let currentLead;
let sellingDomain;

var observer = new MutationObserver(function(mutations) {
    const text = document.querySelector("body > div.main-content.whois > div.content-layout.tile-section.bg-faint > div > div.result-column.col-lg-8.col-xs-12.col-sm-12 > div.whois-result.ux-card.card.content-card-mod > div > div:nth-child(1) > div > div.text");
    // const captchaButton = document.querySelector("#recaptcha-anchor > div.recaptcha-checkbox-border");
    // if (!!captchaButton) {
    //     captchaButton.click()
    // }
    if (!textExists && !!text && text.closest('body')) {
        textExists = true;
        setTimeout(crawlData(text), 500);
    }
});
observer.observe(document.body, { childList: true });

function crawlData(text) {
    debugger;
    email = text.innerText.split('Registrant Email: ').length && text.innerText.split('Registrant Email: ')[1] ? text.innerText.split('Registrant Email: ')[1].split("\n")[0] : '';
    phoneNumber = text.innerText.split('Registrant Phone: ') && text.innerText.split('Registrant Phone: ')[1] ? text.innerText.split('Registrant Phone: ')[1].split("\n")[0] : '';
    domain = text.innerText.split('Domain Name: ') && text.innerText.split('Domain Name: ')[1] ? text.innerText.split('Domain Name: ')[1].split("\n")[0] : '';
    console.log('@@@', email, phoneNumber, domain);
    if (email.includes('domainsbyproxy')) {
        phoneNumber = '';
        email = '';
    }
    if (!email.includes('@')) {
        email = '';
        setTimeout(function() { openModal() }, 300);
    } else if (domain !== '') {
        fetchData();
    }
    else {
        // window.close();
    }

}

function fetchData() {

    let xhr = new XMLHttpRequest();

    xhr.open('GET', 'https://domainlions.com/getGoDaddyDomains', true);

    xhr.responseType = 'json';

    xhr.send();

    xhr.onload = function() {
        debugger;
        leadList = xhr.response;
        currentLead = leadList.find(listItem => listItem.domain.toLowerCase() === domain.toLowerCase());
        console.log('@@@ LEAD ', currentLead);

        updateLead({ ...currentLead, phoneNumber, email, noEmail: email.length > 0 ? false : true });
    };

}

function updateLead(lead) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", 'https://domainlions.com:8443/control/updateWhoisInfo');
    xhr.setRequestHeader('Content-Type', 'application/json');

    //Send the proper header information along with the request
    // xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function() { // Call a function when the state changes.
        if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
            window.close();
            console.log('Request succeeded with JSON response', xhr.response);
        }
    }
    xhr.send(JSON.stringify(lead));
}

function openModal() {
    debugger;
    let el = document.querySelector("body > div.main-content.whois > div.content-layout.tile-section.bg-faint > div > div.result-column.col-lg-8.col-xs-12.col-sm-12 > div.whois-result.ux-card.card.content-card-mod > div > div:nth-child(2) > div > div.contact-registrant-link.whois-link > a");

    if (el) {
        el.click();
        let xhr = new XMLHttpRequest();
        xhr.open("GET", `https://domainlions.com:8443/control/getSellingDomainForGoDaddy?domain=${domain}`);
        xhr.responseType = 'text';

        xhr.send();

        xhr.onload = function() {
            sellingDomain = xhr.response;
            if (!!sellingDomain) {
                setTimeout(populateModal(sellingDomain), 500);
            } 3
        };
    } else {
        let xhr = new XMLHttpRequest();
        xhr.open("GET", `https://domainlions.com:8443/control/getSellingDomainForGoDaddy?domain=${domain}`);
        xhr.responseType = 'text';

        xhr.send();

        xhr.onload = function() {
            window.close();
        };

    }




}

function populateModal(sellingDomain) {
    debugger;
    document.querySelector("#inputEmailAddress").value = "david@domainlions.net";


    let xhr = new XMLHttpRequest();
    xhr.open("GET", `https://domainlions.com:8443/control/getMessageForGoDaddy?domain=${domain}`);
    xhr.responseType = 'text';

    xhr.send();

    xhr.onload = function() {
        let message = xhr.response;
        document.querySelector("#inputContactReason").click();
        document.querySelector("#inputContactReason").value = message;
        document.querySelector("#inputContactReason").click();

        watchForSubmit(false);

    };


    // let message = `Hi, domain ${sellingDomain.toUpperCase()} is being sold: domainlions.com/domains/offer/${sellingDomain}`
    // if (sellingDomain.length >= 18) {
    //     message = `Hi, for domain ${sellingDomain.toUpperCase()}: domainlions.com/domains/offer/${sellingDomain}`
    // }
    // if (sellingDomain.length >= 23) {
    //     message = `Hi, new domain on sale: domainlions.com/domains/offer/${sellingDomain}`
    // }

    // document.querySelector("#inputContactReason").click();
    // document.querySelector("#inputContactReason").value = message;
    // document.querySelector("#inputContactReason").click();

}


function watchForSubmit(elExist) {
    setTimeout(() => {
        const text = document.querySelector("#Registrant");
        if (!elExist && !!text && text.style.display !== 'none') {
            debugger;
            elExist = true;
            //    SUBMITED!!!
            let xhr = new XMLHttpRequest();
            xhr.open("GET", `https://domainlions.com:8443/control/setLeadAsDone?domain=${domain}`);
            xhr.responseType = 'text';

            xhr.send();

            xhr.onload = function() {
                setTimeout(() => {
                    window.close();
                    return;
                }, 500)
            };

        } else {
            watchForSubmit(false);
        }
    }, 200)
}







// setTimeout(() => {

//     const forms = document.getElementsByTagName("form");

//     const lastNameStrings = ['last', 'nachname', 'apellido', 'famil'];
//     const nameStrings = ['name', 'nom', 'nombre', 'naam'];
//     const emailStrings = ['email', 'mail'];
//     const phoneStrings = ['phone', 'telephone', 'number', 'telefon', 'handy', 'tel', 'fax'];
//     const messageStrings = ['message', 'comment', 'nachricht', 'bericht'];
//     const streetStrings = ['street', 'strasse', 'rue'];
//     const zipStrings = ['zip', 'code', 'postcode', 'plz'];
//     const locationStrings = ['location', 'place', 'city', 'state', 'ort'];
//     const companyStrings = ['company', 'firm', 'entreprise', 'unternehmen'];
//     const subjectStrings = ['subject', 'title', 'topic'];
//     const contactStrings = ['contact', 'person'];

//     const formValue = {
//         name: 'David',
//         lastName: 'Pavel',
//         email: 'david@domainlions.net',
//         phone: '16615059573',
//         message: 'Hi we are selling similar domain Contact us',
//         street: '2311 Almondwood Avenue,',
//         zip: '93535',
//         location: 'LA, USA',
//         company: 'Domain Lions',
//         subject: 'Similar Domain Available',
//     }



//     for (let i = 0;i < forms.length;i++) {
//         const inputFields = [...forms[i].getElementsByTagName("input"), ...forms[i].getElementsByTagName("textarea")];
//         debugger;
//         for (let i = 0;i < inputFields.length;i++) {
//             patchFieldValue(inputFields[i]);
//         }

//         const selectFields = forms[i].getElementsByTagName("select");

//         for (let i = 0;i < selectFields.length;i++) {
//             patchSelect(selectFields[i]);
//         }

//     }

//     function patchSelect(field) {
//         field.value = field.options[2].value
//     }


//     function patchFieldValue(field) {
//         let withLastName = false;

//         lastNameStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string) || field.id.toLowerCase().includes(string) || field.className.toLowerCase().includes(string)) {
//                 field.value = formValue.lastName;
//                 withLastName = true;
//             }
//         });

//         nameStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string) || field.id.toLowerCase().includes(string)) {
//                 if (withLastName) {
//                     field.value = formValue.name;
//                 } else {
//                     field.value = formValue.name + ' ' + formValue.lastName;
//                 }
//             }
//         });

//         contactStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string) || field.id.toLowerCase().includes(string)) {
//                 field.value = formValue.name + ' ' + formValue.lastName;
//             }
//         });

//         emailStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.type.toLowerCase().includes('email') || field.id.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string)) {
//                 field.value = formValue.email;
//             }
//         });

//         phoneStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.type.toLowerCase().includes('tel') || field.id.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string)) {
//                 field.value = formValue.phone;
//             }
//         });

//         messageStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.id.toLowerCase().includes(string) || field.type.toLowerCase().includes('textarea') || field.placeholder.toLowerCase().includes(string)) {
//                 field.value = formValue.message;
//             }
//         });

//         streetStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.id.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string)) {
//                 field.value = formValue.street;
//             }
//         });

//         zipStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.id.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string)) {
//                 field.value = formValue.zip;
//             }
//         });

//         locationStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.id.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string)) {
//                 field.value = formValue.location;
//             }
//         });

//         companyStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.id.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string)) {
//                 field.value = formValue.company;
//             }
//         });

//         subjectStrings.forEach(string => {
//             if (field.name.toLowerCase().includes(string) || field.className.toLowerCase().includes(string) || field.id.toLowerCase().includes(string) || field.placeholder.toLowerCase().includes(string)) {
//                 field.value = formValue.subject;
//             }
//         });





//     }
// }, 1000);